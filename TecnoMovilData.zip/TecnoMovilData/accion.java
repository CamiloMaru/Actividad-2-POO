public enum accion {
    ENTRADA, 
    SALIDA
}